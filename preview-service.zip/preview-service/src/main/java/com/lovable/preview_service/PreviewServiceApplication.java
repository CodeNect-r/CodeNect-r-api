package com.lovable.preview_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreviewServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreviewServiceApplication.class, args);
	}

}
